# Sivaranjani - A20436206
getwd()
setwd('D:/Spring-19/For Submission/HW7/')

# Loading File and Finding Missing values
Auto_Data=read.table('HW7_AutoMPG.csv',header=T,sep=',',na.strings=c("?"))

# Replacing ? with mean values for column HP
Auto_Data$horsepower=ifelse(is.na(Auto_Data$horsepower),ave(Auto_Data$horsepower,FUN=function(x)mean(x,na.rm=TRUE)),Auto_Data$horsepower)
Auto_Data$horsepower

#scatter plot for each predictors
plot(Auto_Data$mpg,Auto_Data$cylinders)
plot(Auto_Data$mpg,Auto_Data$displacement)
plot(Auto_Data$mpg,Auto_Data$horsepower)
plot(Auto_Data$mpg,Auto_Data$weight)
plot(Auto_Data$mpg,Auto_Data$acceleration)
plot(Auto_Data$mpg,Auto_Data$year)
plot(Auto_Data$mpg,Auto_Data$origin)


#  Correlation plot for traindata
cor(Auto_Data) 

# Shuffling of data
Auto_Data[sample(nrow(Auto_Data)),]
Selectdata=sample(1:nrow(Auto_Data),0.8*nrow(Auto_Data))

# Data split or Random sampling after shuffling
traindata=Auto_Data[Selectdata,] # 75% of 398 row
testdata=Auto_Data[-Selectdata,] 

# Assigning Variables - train data
mpg=traindata$mpg
cylinders=traindata$cylinders
displacement=traindata$displacement
horsepower=traindata$horsepower
weight=traindata$weight
acceleration=traindata$acceleration
year=traindata$year
origin=traindata$origin


# Model 1: Building model with all variables 

Model1=lm(formula=mpg~cylinders+displacement+horsepower+weight+acceleration+year+origin)
summary(Model1)

# Model 2: Building model with using dummy variables for categorical data

Model2=lm(formula=mpg~as.factor(cylinders)+displacement+horsepower+weight+acceleration+as.factor(year)+as.factor(origin))
summary(Model2)

# Model 3: Building model only with continuous variables 

Model3=lm(formula=mpg~displacement+horsepower+weight+acceleration)
summary(Model3)

# Model 4: Building models only with predictors having strong correlation with Y
Model4=lm(formula=mpg~cylinders+displacement+horsepower+weight)
summary(Model4)

# Model 5: Building model with all variables except year

Model5=lm(formula=mpg~as.factor(cylinders)+displacement+horsepower+weight+acceleration+origin,data=traindata)
summary(Model5)

# Model 6: Building models only with predictors using dummy variable having strong correlation with Y
Model6=lm(formula=mpg~as.factor(cylinders)+displacement+horsepower+weight)
summary(Model6)


# Backward elimination  using P-value : Manually

# removing acceleration from Model 1
Model7=lm(formula=mpg~cylinders+displacement+horsepower+weight+year+origin)
summary(Model7)


# removing cylinders from Model 7
Model8=lm(formula=mpg~displacement+horsepower+weight+year+origin)
summary(Model8)


# removing horsepower from Model 8
Model9=lm(formula=mpg~displacement+weight+year+origin)
summary(Model9)


# removing displacement from Model 9
Model10=lm(formula=mpg~weight+year+origin)
summary(Model10)

# Backward elimination  using AIC/BIC-value :step function

Model11=step(Model2,direction ="backward", trace=T)
summary(Model11)

# base model for Forward and stepwise
Base_Model=lm(formula=mpg~weight)
summary(Base_Model)

#  Linear Model - after Forward  Model  
Model12=step(Base_Model,scope=list(upper=Model1,lower=~1),direction ="forward", trace=T)
summary(Model12)
 
 
#  Linear Model - after Both direction Model  
Model13=step(Base_Model,scope=list(upper=Model2,lower=~1),direction ="both", trace=T)
summary(Model13)
 

#  Linear Model - Subset method
install.packages('leaps')
library(leaps)

Subset_Select=leaps(y=traindata[,1],x=traindata[,cbind(2,3,4,5,6,7,8)],names=names(traindata[,cbind(2,3,4,5,6,7,8)]),method="adjr2")
Subset_Select
# model 48 is best

Model14=lm(formula=mpg~cylinders+displacement+horsepower+weight+year+origin,data=traindata)
summary(Model14)
# Residual Analysis

# For Model 10
# Verify Constance variance
Residual10 = rstandard(Model10)

#step1 : Standardized residual vs predicted values
plot(fitted(Model10), Residual10, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red')

# For Model 11
# Verify Constance variance
Residual11 = rstandard(Model11)

#step1 : Standardized residual vs predicted values
plot(fitted(Model11), Residual11, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red')

# For Model 12
# Verify Constance variance
Residual12 = rstandard(Model12)

#step1 : Standardized residual vs predicted values
plot(fitted(Model12), Residual12, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red')


# Log transformation for Y variable 
# Model 15:Log transform for Model 10

Model15=lm(formula=log(mpg)~weight+year+origin)
summary(Model15)


# Model 16:Log Transformation for Model 11
Model16=lm(log(mpg) ~ weight + as.factor(year)+as.factor(cylinders)+as.factor(origin) + horsepower + displacement,data=traindata)
summary(Model16)


# Model 17:Log Transformation for Model 12
Model17=lm(log(mpg)~weight + year + origin + displacement + horsepower,data = traindata)
summary(Model17)

# Residual Analysis after Transformation
# Model 15:Log transform for Model 10
# Verify Constance variance
Residual15 = rstandard(Model15)

#step1 : Standardized residual vs predicted values
plot(fitted(Model15), Residual15, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red') 

# Verify Linearity relationship # Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(1,3))

#step2 : Standardized residual vs weight values
plot(weight, Residual15, main="Residuals vs weight") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs year values
plot(year, Residual15, main="Residuals vs year") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(origin, Residual15, main="Residuals vs origin") 
abline(a=0, b=0, col='red')

# Model 16:Log Transformation for Model 11
# Verify Constance variance
Residual16 = rstandard(Model16)
#step1 : Standardized residual vs predicted values
plot(fitted(Model16), Residual16, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red') 


# Verify Linearity relationship # Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(2,3))

#step2 : Standardized residual vs weight values
plot(weight, Residual16, main="Residuals vs weight") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs year values
plot(year, Residual16, main="Residuals vs year") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(origin, Residual16, main="Residuals vs origin") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(displacement, Residual16, main="Residuals vs displacement") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(horsepower, Residual16, main="Residuals vs horsepower") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(cylinders, Residual16, main="Residuals vs cylinders") 
abline(a=0, b=0, col='red')


# Model 17:Log Transformation for Model 12
# Verify Constance variance
Residual17 = rstandard(Model17)
#step1 : Standardized residual vs predicted values
plot(fitted(Model17), Residual17, main="Residuals vs Predicted plot") 
abline(a=0, b=0, col='red') 

# Verify Linearity relationship # Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(2,3))

#step2 : Standardized residual vs weight values
plot(weight, Residual17, main="Residuals vs weight") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs year values
plot(year, Residual17, main="Residuals vs year") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(origin, Residual17, main="Residuals vs origin") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(displacement, Residual17, main="Residuals vs displacement") 
abline(a=0, b=0, col='red')

#step2 : Standardized residual vs origin values
plot(horsepower, Residual17, main="Residuals vs horsepower") 
abline(a=0, b=0, col='red')

# Verify Linearity relationship
# Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(1,3))

plot(year, Residual10, main=" Residuals vs Year") 
abline(a=0, b=0, col='red') 

plot(weight, Residual10, main="Residuals vs weight") 
abline(a=0, b=0, col='red')

plot(origin, Residual10, main="Residuals vs origin") 
abline(a=0, b=0, col='red')

# Verify Normal Distribution - Step 3 : Normality Test 
# Shapiro test
 
Residual15 = rstandard(Model15)
shapiro.test(Residual15)

Residual16 = rstandard(Model16)
shapiro.test(Residual16) 

Residual17 = rstandard(Model17)
shapiro.test(Residual17) 

# QQ Plot
qqnorm(Residual15)
qqline(Residual15,col=2)

qqnorm(Residual16)
qqline(Residual16,col=2)

qqnorm(Residual17)
qqline(Residual17,col=2)

# Model Enhancement
# Identification of Multi Collinearity Problem
install.packages("car",dependencies = TRUE)
library(car)

vif(Model15)
vif(Model16)
vif(Model17)

# Resolving Multi Collinearity problem for Model 16 in post processing
# Removing displacement
Model18=lm(formula = log(mpg) ~ weight + as.factor(year) + as.factor(cylinders) + 
             as.factor(origin) + horsepower, data = traindata)
summary(Model18)
vif(Model18)

# Resolving Multi Collinearity problem for Model 17 in post processing
# Removing displacement , Horsepowers

Model19=lm(log(mpg)~weight + year + origin,data = traindata)
summary(Model19)
vif(Model19)

Residual18 = rstandard(Model18)
shapiro.test(Residual18)

Residual19 = rstandard(Model19)
shapiro.test(Residual19)

lm(formula = log(mpg) ~ weight + year + origin + displacement + 
     horsepower, data = traindata)

# Finding Influential points
cooks.distance(Model15)
cooks.distance(Model16)
cooks.distance(Model17)
cooks.distance(Model18)
cooks.distance(Model19)

# Finding Root mean square
obs1=testdata[,"mpg"]
obs2=traindata[,"mpg"]

# for model 15
P_Train15=exp(predict.glm(Model15,traindata) )
RMSE_Train_M15=sqrt((obs2-P_Train15)%*%(obs2-P_Train15)/nrow(traindata))
RMSE_Train_M15

P_Test15=exp(predict.glm(Model15,testdata) )
RMSE_Test_M15=sqrt((obs1-P_Test15)%*%(obs1-P_Test15)/nrow(testdata))
RMSE_Test_M15

# for model 16
P_Train16=exp(predict.glm(Model16,traindata)) 
RMSE_Train_M16=sqrt((obs2-P_Train16)%*%(obs2-P_Train16)/nrow(traindata))
RMSE_Train_M16

P_Test16=exp(predict.glm(Model16,testdata)) 
RMSE_Test_M16=sqrt((obs1-P_Test16)%*%(obs1-P_Test16)/nrow(testdata))
RMSE_Test_M16

# for model 17
P_Train17=exp(predict.glm(Model17,traindata) )
RMSE_Train_M17=sqrt((obs2-P_Train17)%*%(obs2-P_Train17)/nrow(traindata))
RMSE_Train_M17

P_Test17=exp(predict.glm(Model17,testdata) )
RMSE_Test_M17=sqrt((obs1-P_Test17)%*%(obs1-P_Test17)/nrow(testdata))
RMSE_Test_M17

# for model 18
P_Train18=exp(predict.glm(Model18,traindata) )
RMSE_Train_M18=sqrt((obs2-P_Train18)%*%(obs2-P_Train18)/nrow(traindata))
RMSE_Train_M18

P_Test18=exp(predict.glm(Model18,testdata) )
RMSE_Test_M18=sqrt((obs1-P_Test18)%*%(obs1-P_Test18)/nrow(testdata))
RMSE_Test_M18

# for model 19
P_Train19=exp(predict.glm(Model19,traindata) )
RMSE_Train_M19=sqrt((obs2-P_Train19)%*%(obs2-P_Train19)/nrow(traindata))
RMSE_Train_M19

P_Test19=exp(predict.glm(Model19,testdata))
RMSE_Test_M19=sqrt((obs1-P_Test19)%*%(obs1-P_Test19)/nrow(testdata))
RMSE_Test_M19
