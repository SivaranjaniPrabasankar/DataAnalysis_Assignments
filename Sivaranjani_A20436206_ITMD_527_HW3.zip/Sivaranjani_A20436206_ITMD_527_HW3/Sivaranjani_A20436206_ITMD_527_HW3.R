#Sivaranjani A20436206
getwd()

#Modifying working directory
setwd('D:/Spring-19/For Submission/')


# Reading CSV Files
G1_G2=read.csv('HW3_CTA.csv',header=T)
# Extracting data in column
G1=subset(G1_G2,select=c(G1))
G2=subset(G1_G2,select=c(G2))

# Installing necessary packages
install.packages("BSDA")
library(BSDA)

# Method 1 : One Sampled - Two tailed Z test
# Finding Difference between two column
Diff = G2-G1
print(Diff)



# TWO SAMPLED TEST PAIR TEST
Query1=data.matrix(Diff)
z.test(Query1,NULL,alternative="two.sided",mu=0,sigma.x = sd(Query1),sigma.y = NULL,conf.level = 0.99)
