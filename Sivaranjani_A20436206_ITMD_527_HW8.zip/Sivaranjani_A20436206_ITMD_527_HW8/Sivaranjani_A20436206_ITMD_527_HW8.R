# Sivaranjani Prabasankar A20436206
getwd();
setwd('D:/Spring-19/For Submission/HW8')

sampledata=read.table('HW6_clerical_Q2.txt',header=T)
install.packages("car")
library(car)
library(plyr)

# Data Preprocessing : Converting Monday to Thursday as Weekday ( 0 ) and Friday to Sunday as weekend ( 1)
sampledata$DAY=revalue(sampledata$DAY,c("M"="0"))
sampledata$DAY=revalue(sampledata$DAY,c("T"="0"))
sampledata$DAY=revalue(sampledata$DAY,c("W"="0"))
sampledata$DAY=revalue(sampledata$DAY,c("Th"="0"))
sampledata$DAY=revalue(sampledata$DAY,c("F"="1"))
sampledata$DAY=revalue(sampledata$DAY,c("S"="1"))

# Assigning Variable
Day=sampledata$DAY
Hours=sampledata$HOURS
Mail=sampledata$MAIL
Cert=sampledata$CERT
Acc=sampledata$ACC
Change=sampledata$CHANGE
Check=sampledata$CHECK
Misc=sampledata$MISC
Tickets=sampledata$TICKETS

#Qn 3 - A

Full_Model=glm(Day~Hours+Mail+Cert+Acc+Change+Check+Misc+Tickets, data=sampledata,family=binomial())
summary(Full_Model)

#Qn 3 - B
# base model for Forward and stepwise
Base_Model=glm(Day~Hours,data=sampledata,family=binomial())
summary(Base_Model)

#  Linear Model - after Backward  Model  
Back_Model=step(Full_Model,direction ="backward", trace=T)
summary(Back_Model)

#  Linear Model - after Forward  Model  
Fwd_Model=step(Base_Model,scope=list(upper=Full_Model,lower=~1),direction ="forward", trace=T)
summary(Fwd_Model)

#  Linear Model - after step wise  Model  
Step_Model=step(Base_Model,scope=list(upper=Full_Model,lower=~1),direction ="both", trace=T)
summary(Step_Model)

# Qn 3- D
#Cooks distance : 0.0769230769230769
influence.measures(Full_Model)
influence.measures(Back_Model) # 2  + 4 = 6 pts {3,9,18,29,31,35}
influence.measures(Fwd_Model)
influence.measures(Step_Model)
