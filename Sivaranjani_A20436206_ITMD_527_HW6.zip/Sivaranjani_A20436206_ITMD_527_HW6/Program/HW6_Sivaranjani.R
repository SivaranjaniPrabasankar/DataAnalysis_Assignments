# Programmed by Sivaranjani
getwd();
setwd('D:/Spring-19/For Submission/HW6_DA/Dataset')

# Importing file
energy_consump=read.table('HW6_energytemp.txt',header=T)
print(energy_consump)

# Defining variables
energy=energy_consump$energy
tempd=energy_consump$temp
print(energy)
# Qn 1 A - Scatter plot
plot(tempd,energy,xlab="Temperature", ylab="Energy")

# Qn 1 B - Find cubic model
tempd2=tempd^2
print(tempd2)
tempd3=tempd^3
print(tempd3)


Cubic=lm(energy~tempd+tempd2+tempd3, CV=FALSE)
summary(Cubic)

# 8.105e-11 < 0.05 F test passed - atleast one has liner r'ship with Y
# All X variables < 0.05 hence backward elim or fwd selection not required

# Qn 1 C Goodness of FIT
fit = rstandard(Cubic)
#step1 : Standardized residual vs predicted values

plot( fitted(Cubic), fit, main="Predicted vs residuals plot") 
abline(a=0, b=0, col='red')


# Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(1,3))
plot(tempd, fit, main=" Temperature vs Energy ") 
abline(a=0, b=0, col='red')

plot(tempd2, fit, main=" Temperature square vs Energy") 
abline(a=0, b=0, col='red')

plot(tempd3, fit, main=" Temperature cube vs Energy") 
abline(a=0, b=0, col='red')

# Step 3 : Normality Test 
# Shapiro test
shapiro.test(fit) 
# QQ Plot
qqnorm(fit)
qqline(fit,col=3)

# p-value = 0.2769 > 0.05

new = data.frame (tempd=c(10), tempd2=c(100), tempd3=c(1000))
print(new)
# compute predicted value and standard error 
predict(Cubic,new,se.fit=T)
# compute predicted value and prediction interval
predict(Cubic,new,se.fit=T,interval="prediction",level=0.95)

inf_pts=influence.measures(Cubic)
print(inf_pts)

cooks.distance(Cubic)
# VALUE AT 22 & 23 ARE OUTLIERS

# Qn 3
# Importing file
Mileage_File=read.table('HW6_mileage.txt',header=T)
print(Mileage_File)
model=Mileage_File$MAKEMODEL
hp=Mileage_File$HP
mpg=Mileage_File$MPG
weight=Mileage_File$WT

plot(Mileage_File)

mileage=lm(mpg~hp+weight)
summary(mileage)

fit_mpg = rstandard(mileage)
# Residual : For fitted model
#step1 : Standardized residual vs predicted values
plot( fitted(mileage), fit_mpg, main="Predicted vs residuals plot") 
abline(a=0, b=0, col='red')


# Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(1,3))
plot(hp, fit_mpg, main=" Horse Power vs Mileage Per Gallon ") 
abline(a=0, b=0, col='red')

plot(weight, fit_mpg, main=" Weight vs Mileage per gallon") 
abline(a=0, b=0, col='red')

# Step 3 : Normality Test 
# Shapiro test
shapiro.test(fit_mpg) 
# QQ Plot
qqnorm(fit_mpg)
qqline(fit_mpg,col=2)

# Y Transformation
mpg_LTrans=log(Mileage_File$MPG)
mpg_ITrans=1/(Mileage_File$MPG)
mpg_STrans=sqrt(Mileage_File$MPG)
print(mpg_LTrans)
print(mpg_ITrans)
print(mpg_STrans)

mileage_T1=lm(mpg_LTrans~hp+weight)
mileage_T2=lm(mpg_ITrans~hp+weight)
mileage_T3=lm(mpg_STrans~hp+weight)

summary(mileage_T1)
summary(mileage_T2)
summary(mileage_T3)


#Log transform = Best model HEnce choosing it for further analysis

# Residual for transformation
fit_transform = rstandard(mileage_T1)

#step1 : Standardized residual vs predicted values
plot( fitted(mileage_T1), fit_transform, main="Predicted vs residuals plot") 
abline(a=0, b=0, col='red')


# Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(1,2))
plot(hp, fit_transform, main=" Horse Power vs Mileage Per Gallon ") 
abline(a=0, b=0, col='red')

plot(weight, fit_transform, main=" Weight vs Mileage per gallon") 
abline(a=0, b=0, col='red')

# Step 3 : Normality Test 
# Shapiro test
shapiro.test(fit_transform) 
# QQ Plot
qqnorm(fit_transform)
qqline(fit_transform,col=2)

FB_1=step(mileage, direction="both", trace=T) 
summary(FB_1)

FB_2=step(mileage_T1, direction="both", trace=T) 
summary(FB_2)

# Qn 4 
# Importing file
Clerical=read.table('HW6_clerical_Q2.txt',header=T)
print(Clerical)
hours=Clerical$HOURS
day=Clerical$DAY
plot(hours~day)
attach(Clerical)

# Grouping

Monday=Clerical[which(DAY=='M'),]
Tuesday=Clerical[which(DAY=='T'),]
Wednesday=Clerical[which(DAY=='W'),]
Thursday=Clerical[which(DAY=='Th'),]
Friday=Clerical[which(DAY=='F'),]
Saturday=Clerical[which(DAY=='S'),]

# Display Group
Monday
Tuesday
Wednesday
Thursday
Friday
Saturday

# Detail of group
summary(Monday)
summary(Tuesday)
summary(Wednesday)
summary(Thursday)
summary(Friday)
summary(Saturday)

# Regression model
Clerical_Model=lm(hours~day)
summary(Clerical_Model)
