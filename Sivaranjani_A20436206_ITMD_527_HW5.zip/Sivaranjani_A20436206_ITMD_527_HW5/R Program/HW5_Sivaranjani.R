# Sivaranjani Prabasankar A20436206
getwd();
setwd('D:/Spring-19/For Submission/HW5_DA')

sampledata=read.table('HW5_DATA.txt',header=T)

sample_sales=sampledata$sales
sample_title=sampledata$title
sample_footage=sampledata$footage
sample_pc=sampledata$pc
sample_apple=sampledata$apple

# To Shuffle
#datasplit = sample (1:nrow(sampledata), 0.7*nrow(sampledata)) 
#traindata = sampledata[datasplit,]
#testdata = sampledata[-datasplit,]

# Data without shuffling
traindata=sampledata[1:36,] # 70% of 52 row
testdata=sampledata[37:52,] # 30% of 52 row

# Qn 1 : Import the data in R and define the variables as: sales, title, footage, pc and apple.
train_sales=traindata$sales
train_title=traindata$title
train_footage=traindata$footage
train_pc=traindata$pc
train_apple=traindata$apple

test_sales=testdata$sales
test_title=testdata$title
test_footage=testdata$footage
test_pc=testdata$pc
test_apple=testdata$apple

print(sampledata)
print(traindata)
print(testdata)

# Qn 2: Scatter plot for Sales Vs Title
plot(sample_title,sample_sales,xlab="Title", ylab="Sales") # Before calculating & splitting data

# Qn 2: Scatter plot for Sales Vs Footage
plot(sample_footage,sample_sales,xlab="Footage", ylab="Sales") # Before calculating & splitting data

# Qn 3: Scatter plot for taindata
plot(traindata)
# Qn 3 : Correlation for train data
cor(traindata)
cor(cbind(train_sales,train_title,train_footage,train_pc,train_apple))

# Qn 4 : Linear Model  sales Y and title, footage, pc and apple X 

Model1=lm(formula=train_sales~train_title+train_footage+train_pc+train_apple)
summary(Model1)


# Qn 5  BACKWARD ELIMINATION In built function- Removing title 
Backward=step(Model1, direction="backward", trace=T)
summary(Backward)
Model2=lm(formula=train_sales~train_footage+train_pc+train_apple)
summary(Model2)

# Qn 9 Residual Analysis for model 2
residual = rstandard(Model2)
#step1 : Standardized residual vs predicted values

plot( fitted(Model2), residual, main="Predicted vs residuals plot") 
abline(a=0, b=0, col='red')

# Step 2 : Standardized residual vs x variables
attach(mtcars) 
par(mfrow=c(1,3))
plot(train_footage, residual, main=" Footage vs residuals plot") 
abline(a=0, b=0, col='red')

plot(train_pc, residual, main=" PC vs residuals plot") 
abline(a=0, b=0, col='red')

plot(train_apple, residual, main=" Apple vs residuals plot") 
abline(a=0, b=0, col='red')

# Step 3 : Normality Test 
# Shapiro test
shapiro.test(residual) 
# QQ Plot
qqnorm(residual)
qqline(residual,col=3)

# Qn 10 Forward selection
Model3=lm(formula=train_sales~train_pc,data=traindata)
Forward=step(Model3,scope=list(upper=Model1, lower=~1), direction="forward", trace=T) 
summary(Forward)
Model4=lm(formula=train_sales~train_pc+train_footage+train_apple)
summary(Model4)

# Qn 11 - RMSE
# RMSE for backward elimination model
Y1=predict.glm(MLR_B1,testdata) 

# where MLRB1 is LM of traindata without title and test data is the row from 37- 52 dataset
obs=testdata[,"sales"]
rmse_model1=sqrt((obs-Y1)%*%(obs-Y1))/nrow(testdata)
rmse_model1

# RMSE for forward selection model
Y2=predict.glm(MLR_fwd,testdata)
# where MLR_fwd is LM of traindata without title and test data is the row from 37- 52 dataset
rmse_model2=sqrt((obs-Y2)%*%(obs-Y2))/nrow(testdata)
rmse_model2

# RMSE for full model
Y3=predict.glm(MLR,testdata)
# where MLR is LM of traindata with title and test data is the row from 37- 52 dataset
rmse_model2=sqrt((obs-Y3)%*%(obs-Y3))/nrow(testdata)
rmse_model2