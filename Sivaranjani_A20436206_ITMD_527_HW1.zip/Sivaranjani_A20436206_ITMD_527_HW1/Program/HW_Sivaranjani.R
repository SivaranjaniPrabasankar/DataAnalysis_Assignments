# Sivaranjani_A20436206
#Getting present working Directory
getwd()

#Modifying working directory
setwd('D:/Spring-19/ITMD_527_DATA Analytics/Homework/')

# Query1
# Loading data from CSV file
Grade_Smallset=read.csv('Case1_Student Grades_Small.csv',header=T)
# read.table('Case1_Student Grades_Small.csv',header=T,sep=",")

#Printing fields from loaded CSV file
names(Grade_Smallset)

#Creating subset for Degree,Hours on Assignment,Hours on Game,Exam & GradeLetter using column names
Query_4_0=subset(Grade_Smallset,select=c(Degree,Hours.on.Assignments,Hours.on.Games,Exam,Grade))

#Creating subset for Degree,Hours on Assignment,Hours on Game,Exam & GradeLetter using column ID's
Query_4_1=subset(Grade_Smallset,select=c(5,7,8,10,11))

# Fetching top rows 
head(Query_4_0)
head(Query_4_1)
# ============ ============ ============ ============ ============ ============ ============
# Sivaranjani_A20436206
# 2 query
Degree=Grade_Smallset$Degree
print(Degree)

# Installing and loading required package 
install.packages('plyr')
library(plyr)

#Calculating Relative Frequency
CRF_Degree=table(Grade_Smallset$Degree)/nrow(Grade_Smallset)
print(CRF_Degree)
#Degree_Label=count(Degree)
#print(Degree_Label)
Query_4_2=pie(CRF_Degree)
# ============ ============ ============ ============ ============ ============ ============
# Sivaranjani_A20436206
# 3 Query
Exam=Grade_Smallset$Exam
print(Exam)

#Plotting Histogram
H1=hist(Exam,main="Histogram for Exam")

#Plotting Histogram with curve
X_Exam=seq(min(Exam),max(Exam),length=40)
print(X_Exam)
Y_Exam=dnorm(X_Exam,mean=mean(Exam),sd=sd(Exam))
Y_Exam=Y_Exam*diff(H1$mids[1:2])*length(Exam)
print(Y_Exam)

Histogram_Exam=lines(X_Exam,Y_Exam,col="Blue",lwd=2)

#Descriptive Statistics
# For mean,standar deviation, variance, min,max,range,
Query_4_3A=summary(Exam)
print(Query_4_3A)

# Installing and loading required package 
install.packages("psych")
library(psych)

# For Q1,Q3,Median
Query_4_3B=describe(Exam)
print(Query_4_3B)
# ============ ============ ============ ============ ============ ============ ============
# Sivaranjani_A20436206
# 4 Query

Assignment=Grade_Smallset$Hours.on.Assignments
print(Assignment)
H1=hist(Assignment,main="Histogram for Assingments")

#Plotting Histogram with curve
X_Assgn=seq(min(Assignment),max(Assignment),length=40)
Y_Assgn=dnorm(X_Assgn,mean=mean(Assignment),sd=sd(Assignment))
Y_Assgn=Y_Assgn*diff(H1$mids[1:2])*length(Assignment)
Histogram_Assgn=lines(X_Assgn,Y_Assgn,col="Green",lwd=2)

Games=Grade_Smallset$Hours.on.Games
print(Games)

H2=hist(Games,main="Histogram for Games")
#Plotting Histogram with curve
X_Games=seq(min(Games),max(Games),length=40)
Y_Games=dnorm(X_Games,mean=mean(Games),sd=sd(Games))
Y_Games=Y_Games*diff(H2$mids[1:2])*length(Games)
Histogram_Games=lines(X_Games,Y_Games,col="Red",lwd=5)
# ============ ============ ============ ============ ============ ============ ============
help("compare")

